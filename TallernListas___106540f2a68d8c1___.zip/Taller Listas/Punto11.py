persona = {
    "nombre" : "Cristian Alejandro",
    "edad" : 18,
    "ciudad" : "Medellín" 
}
edad = persona["edad"]
print(edad)