persona = {
    "nombre" : "Cristian Alejandro",
    "edad" : 18
}

valores = list(persona.values())
print(valores)