Mixta = ["Cristian Alejandro", 88, 1.85]
print(Mixta)