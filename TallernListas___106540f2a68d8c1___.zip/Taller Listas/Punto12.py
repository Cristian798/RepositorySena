persona = {
    "nombre" : "Cristian Alejandro",
    "edad" : 18,
    "ciudad" : "Medellín" 
}
persona["edad"] = 88 
print(persona)