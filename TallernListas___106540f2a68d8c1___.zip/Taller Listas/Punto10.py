persona = {
    "nombre" : "Cristian Alejandro",
    "edad" : 18,
    "ciudad" : "Medellín" 
}

print(persona)