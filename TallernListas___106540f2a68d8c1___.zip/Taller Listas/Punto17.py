numerosPares = [numero for numero in range(1, 11) if numero % 2 == 0]
print(numerosPares)