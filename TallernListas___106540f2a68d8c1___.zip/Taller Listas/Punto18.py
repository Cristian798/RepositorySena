cuadrados = [numero ** 2 for numero in range(1, 6)]
print(cuadrados)