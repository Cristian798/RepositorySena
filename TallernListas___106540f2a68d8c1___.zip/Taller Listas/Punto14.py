persona = {
    "nombre" : "Cristian Alejandro",
    "edad" : 18
}

claves = list(persona.keys())
print(claves)