personas = {
    "Cristian": 18,
    "Angie": 17,
    "Alejandro": 88
}

mayores = [nombre for nombre, edad in personas.items() if edad >= 18]
print(mayores)