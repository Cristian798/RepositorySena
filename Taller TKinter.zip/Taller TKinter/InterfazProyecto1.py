import tkinter as tk
from tkinter import ttk

class BarberShopApp:
    def __init__(self, root):
        root.title("H BarberShop")

        header = ttk.Frame(root)
        header.grid(row=0, column=0, sticky="ew")

        ttk.Label(header, text="H BarberShop", font=("Helvetica", 16)).grid(row=0, column=0, padx=10, pady=10)

        services_button = ttk.Button(header, text="Servicios", command=self.show_services)
        services_button.grid(row=0, column=1, padx=10, pady=10)

        samples_button = ttk.Button(header, text="Muestras de trabajo", command=self.show_samples)
        samples_button.grid(row=0, column=2, padx=10, pady=10)

        store_button = ttk.Button(header, text="Tienda Virtual", command=self.show_store)
        store_button.grid(row=0, column=3, padx=10, pady=10)

        content = ttk.Frame(root)
        content.grid(row=1, column=0, sticky="nsew")

        # TODO: 

        footer = ttk.Frame(root)
        footer.grid(row=2, column=0, sticky="ew")

        ttk.Label(footer, text="Contacto").grid(row=0, column=0, padx=10, pady=10)
        ttk.Label(footer, text="Dirección: Cra 95 # 89 - 05").grid(row=1, column=0, padx=10, pady=5)
        ttk.Label(footer, text="Teléfono: 300 246 79 38").grid(row=2, column=0, padx=10, pady=5)

        ttk.Label(footer, text="Horarios").grid(row=0, column=1, padx=10, pady=10)
        ttk.Label(footer, text="Lunes - Viernes: 10:00 A.M - 8:00 P.M").grid(row=1, column=1, padx=10, pady=5)
        ttk.Label(footer, text="Sábados: 7:00 A.M - 10:00 PM").grid(row=2, column=1, padx=10, pady=5)
        ttk.Label(footer, text="Domingos: Cerrado").grid(row=3, column=1, padx=10, pady=5)

        ttk.Label(footer, text="© H BarberShop. Todos los derechos reservados.").grid(row=4, column=0, columnspan=2, pady=10)

    def show_services(self):
        # TODO: 
        pass

    def show_samples(self):
        # TODO: 
        pass

    def show_store(self):
        # TODO: 
        pass

if __name__ == "__main__":
    root = tk.Tk()
    app = BarberShopApp(root)
    root.mainloop()
