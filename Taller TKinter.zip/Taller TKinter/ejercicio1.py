from tkinter import *

def saludar():
    print("Hola a todos")
def minimizar():
    ventana.iconify()

ventana = Tk()
ventana.title("Ejercicio1")
ventana.geometry("400x200")
etiqueta = Label(ventana, text="Desde aqui Saludamos").place(x=30,y=50)
etiqueta2 = Label(ventana, text="Desde aqui minimizamos").place(x=30,y=100)
boton = Button(ventana, text="Dame clic para saludar", fg="green", command=saludar).place(x=200,y=50)
boton2 = Button(ventana, text="Dame clic para minimizar", fg="blue", command=minimizar).place(x=200,y=100)
ventana.mainloop()

        