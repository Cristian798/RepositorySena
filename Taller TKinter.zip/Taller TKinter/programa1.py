from tkinter import *
import time

def parpadear():
    ventana.iconify()
    ventana.after(3000, ventana.deiconify)  # Programa desiconificar después de 3000 milisegundos (3 segundos)

ventana = Tk()
ventana.title("Primera Ventana en Tk")
boton = Button(ventana, text="Evento", command=parpadear)
boton.pack()
ventana.mainloop()
