from tkinter import messagebox

messagebox.showinfo("Hola", "Hola A Todos")
'OK'
messagebox.showwarning("Advertencia", "Esto es un Mensaje de Advertencia")
'OK'
messagebox.askquestion("Pregunta 1", "Cualquier Cosa")
'OK'
messagebox.askokcancel("Pregunta 2", "Cualquier Cosa")
False
messagebox.askyesno("Pregunta 3", "Cualquier Cosa")
True
messagebox.askretrycancel("Pregunta 4", "Cualquier Cosa")