from tkinter import *

def sombrero():
    c.delete("all")
    c.create_oval(180, 180, 320, 320, fill=" # FFEBCD ")
    c.create_polygon(160, 210, 340, 210, 250, 150, fill=color.get())
    c.create_line(210, 240, 240, 240, width=3.0)
    c.create_line(260, 240, 290, 240, width=3.0)
    c.create_line(230, 270, 270, 270, width=3.0)

def fondo():
    c.delete("all")
    c.create_rectangle(0, 0, 500, 500, fill=color.get())

ventana = Tk()
color = StringVar()

c = Canvas(ventana, width=500, height=500)
c.place(x=0, y=0)

c.create_rectangle(0, 0, 500, 500, fill="#4682B4")
c.create_oval(180, 180, 320, 320, fill="#FFEBCD")
c.create_polygon(160, 210, 340, 210, 250, 150, fill="yellow")
c.create_line(210, 240, 240, 240, width=3.0)
c.create_line(260, 240, 290, 240, width=3.0)
c.create_line(230, 270, 270, 270, width=3.0)

combo = Spinbox(ventana, values=("blue", "yellow", "red", "black", "white"), textvariable=color)
combo.place(x=20, y=20)

boton_button = Button(ventana, text="cambiar sombrero", command=sombrero)
boton_button.place(x=165, y=18)

boton_button = Button(ventana, text="cambiar fondo", command=fondo)
boton_button.place(x=285, y=18)

ventana.mainloop()