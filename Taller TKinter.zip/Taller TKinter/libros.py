from tkinter import *
from tkinter import messagebox

libros = []

def agregar():
    t = titulo.get()
    a = autor.get()
    e = editorial.get()
    np = Ndepaginas.get()
    fl = fechalimite.get()
    libros.append(t+"$"+a+"$"+e+"$"+str(np)+"$"+fl)
    escribirLibro()
    messagebox.showinfo("Guardado", "El libro que tiene que leer ha sido guardado")
    titulo.set("")
    autor.set("")
    editorial.set("")
    Ndepaginas.set("")
    fechalimite.set("")
    consultar()

def escribirLibro():
    archivo = open("biblioteca.txt", "w")
    libros.sort()
    for i in libros:
        archivo.write(i+"\n")
    archivo.close()

def eliminarLibro():
    eliminado = eliminarlibro.get()
    removido = False
    for elemento in libros:
        arreglo = elemento.split("$")
        if eliminarlibro.get()==arreglo[0]:
            respuesta = messagebox.askyesno("Eliminar Libro", "Deseas eliminar el libro con el titulo: \n"+eliminado)
            if respuesta:
                libros.remove(elemento)
                removido = True
                escribirLibro()
                consultar()
                respuesta=""
        if removido:
            messagebox.showinfo("Eliminar", "Se ha Eliminado el titulo\n"+eliminado)

def salir():
    sa = messagebox.askyesno("Salir", "¿Deseas Finalizar?")
    if sa==True:
        quit()

def iniciarArchivo():
    archivo = open("biblioteca.txt", "a")
    archivo.close()

def cargar():
    archivo = open("biblioteca.txt", "r")
    linea = archivo.readline()
    if linea:
        while linea:
            if linea[-1]=='\n':
                linea = linea[:-1]
            libros.append(linea)
            linea = archivo.readline()
        archivo.close()


def consultar():
    r = Text(ventana, width=80, height=15)
    libros.sort()
    valores=[]
    r.insert(INSERT, "\Titulo del libro\n")
    r.insert(INSERT, "-----------------------\---------------------------------\n")
    for elemento in libros:
        arreglo = elemento.split("$")
        valores.append(arreglo[0])
        r.insert(INSERT,"\t"+arreglo[0]+"\n Autor:"+arreglo[1]+"\tEditorial:"+arreglo[2]+"\tN° de paginas:"+arreglo[3]+"\tFecha Limite:"+arreglo[4]+"\n")
        r.insert(INSERT, "-----------------------\---------------------------------\n")

    spinTitulo = Spinbox(ventana, value=(valores), textvariable=eliminarlibro, width=70).place(x=110,y=450)
    r.place(x=30,y=195)
    if libros==[]:
        spinTitulo = Spinbox(ventana, value=(valores), width=70).place(x=110,y=450)
    r.config(state=DISABLED)

ventana = Tk()
titulo = StringVar()
autor = StringVar()
editorial = StringVar()
Ndepaginas = IntVar()
fechalimite = StringVar()
eliminarlibro = StringVar()
colorFondo = "#150"
colorLetra = "#fff"
iniciarArchivo()
cargar()
consultar()
ventana.title("Relacion de libros que tengo que leer")
ventana.geometry("700x500")
ventana.config(background=colorFondo)
etiquetaTitulo = Label(ventana, text="Relacion de libros que tengo que leer", bg=colorFondo, fg = colorLetra).place(x=250,y=10)
eTitulo = Label(ventana, text="Titulo: ", bg=colorFondo, fg = colorLetra).place(x=30,y=40)
cTitulo = Entry(ventana, textvariable=titulo,width=70).place(x=120,y=40)
eAutor = Label(ventana, text="Autor: ", bg=colorFondo, fg = colorLetra).place(x=30,y=70)
cAutor = Entry(ventana, textvariable=autor,width=70).place(x=120,y=70)
eEditorial = Label(ventana, text="Editorial: ", bg=colorFondo, fg = colorLetra).place(x=30,y=100)
cEditorial = Entry(ventana, textvariable=editorial,width=70).place(x=120,y=100)
ePaginas = Label(ventana, text="Numero de paginas: ", bg=colorFondo, fg = colorLetra).place(x=30,y=130)
cPaginas = Entry(ventana, textvariable=Ndepaginas,width=70).place(x=120,y=130)
eFecha = Label(ventana, text="Fecha Limite: ", bg=colorFondo, fg = colorLetra).place(x=30,y=160)
cFecha = Entry(ventana, textvariable=fechalimite,width=70).place(x=120,y=160)
botonanadir = Button(ventana, text="agregar", command=agregar, bg="#009",fg="white").place(x=550,y=38)
spinTitulo = Label(ventana, text="Titulo leido: ", bg=colorFondo, fg = colorLetra).place(x=30,y=450)
botonleido = Button(ventana, text="libro ya leido", command=eliminarLibro, bg="#009",fg="white").place(x=550,y=448)
# imgbtn = PhotoImage(file="salir.png")
sal = Button(ventana, command=salir).place(x=550,y=500)
ventana.mainloop()
    