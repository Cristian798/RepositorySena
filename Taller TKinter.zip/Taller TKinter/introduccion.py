from tkinter import *

ventana = Tk()
etiqueta = Label(ventana, text="Hola Mundo!!")
ventana.title("esta es mi primera ventana")
boton = Button(ventana, text="Minimizar", command=ventana.iconify)

boton.pack()
etiqueta.pack()
etiqueta.mainloop()
