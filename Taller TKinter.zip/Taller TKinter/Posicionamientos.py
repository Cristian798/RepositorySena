from tkinter import *

ventana = Tk()
ventana.title("Posicionamientos")
ventana.geometry("400x200")
boton = Button(ventana, text="Posicionamiento Diferente").place(x=10,y=10)
etiqueta = Label(ventana, text="Posicionamiento Diferente").place(x=200,y=10)
etiqueta2 = Label(ventana, text="Posicionamiento Diferente 2").place(x=10,y=30)
etiqueta3 = Label(ventana, text="Posicionamiento Diferente 3").place(x=200,y=30)
ventana.mainloop()