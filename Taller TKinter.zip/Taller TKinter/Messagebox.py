from tkinter import *
from tkinter import messagebox

def obtener():
    messagebox.showinfo("Mensaje", "Tu seleccionaste: "+valor.get())

ventana = Tk()
valor = StringVar()
ventana.title("Uso de Spinbox en Tkinter")
ventana.geometry("400x300")
etiqueta1 = Label(ventana, text="Ejemplo 1 Spinbox: ").place(x=20,y=20)
combo = Spinbox(ventana, values=("Uno","Dos","Tres","Cuatro","Cinco")).place(x=20,y=50)
etiqueta2 = Label(ventana, text="Ejemplo 2 Spinbox: ").place(x=20,y=80)
combo2 = Spinbox(ventana, from_=1, to=10, textvariable=valor).place(x=20,y=110)
boton = Button(ventana, text="Obtener Valor SpinBox", fg="green", command=obtener).place(x=80,y=140)
ventana.mainloop()