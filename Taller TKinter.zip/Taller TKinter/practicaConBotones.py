from tkinter import *

def imprime():
    print("Presionaste el boton imprimir!!")

ventana = Tk()
ventana.title("Segunda Ventana")
botonI = Button(ventana, text="Imprimir", fg="green", command=imprime)
botonI.pack(side=RIGHT)
BotonS = Button(ventana, text="Salir", fg="red", command=ventana.quit)
BotonS.pack(side=LEFT)
ventana.mainloop()


