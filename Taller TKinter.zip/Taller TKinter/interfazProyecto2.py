import tkinter as tk

def iniciar_sesion():
    celular = celular_entry.get()
    contrasena = contrasena_entry.get()
    print("Celular:", celular)
    print("Contraseña:", contrasena)

root = tk.Tk()
root.title("H BarberShop")

container_frame = tk.Frame(root, padx=10, pady=10)
container_frame.pack()

titulo_label = tk.Label(container_frame, text="Iniciar sesión en H BarberShop", font=("Helvetica", 16))
titulo_label.grid(row=0, column=0, columnspan=2, pady=10)

celular_label = tk.Label(container_frame, text="Celular:")
celular_label.grid(row=1, column=0, sticky="e")

celular_entry = tk.Entry(container_frame)
celular_entry.grid(row=1, column=1)

contrasena_label = tk.Label(container_frame, text="Contraseña:")
contrasena_label.grid(row=2, column=0, sticky="e")

contrasena_entry = tk.Entry(container_frame, show="*") 
contrasena_entry.grid(row=2, column=1)

login_button = tk.Button(container_frame, text="Iniciar sesión", command=iniciar_sesion)
login_button.grid(row=3, column=0, columnspan=2, pady=10)

olvide_label = tk.Label(container_frame, text="Olvidé mi contraseña", fg="blue", cursor="hand2")
olvide_label.grid(row=4, column=0, columnspan=2)

volver_label = tk.Label(container_frame, text="Volver al inicio", fg="blue", cursor="hand2")
volver_label.grid(row=5, column=0, columnspan=2)

def olvide_contraseña():
    print("Olvidé mi contraseña")

def volver_al_inicio():
    print("Volver al inicio")

olvide_label.bind("<Button-1>", lambda event: olvide_contraseña())
volver_label.bind("<Button-1>", lambda event: volver_al_inicio())

root.mainloop()
