# def mcd(a, b):
#     while b:
#         a, b = b, a % b
#     return a

# def mcd_cuatro_numeros(num1, num2, num3, num4):
#     mcd_ab = mcd(num1, num2)
#     mcd_cd = mcd(num3, num4)
#     mcd_total = mcd(mcd_ab, mcd_cd)
#     return mcd_total

# num1 = int(input("Ingrese el primer número: "))
# num2 = int(input("Ingrese el segundo número: "))
# num3 = int(input("Ingrese el tercer número: "))
# num4 = int(input("Ingrese el cuarto número: "))

# resultado = mcd_cuatro_numeros(num1, num2, num3, num4)

# print(f"El máximo común divisor de {num1}, {num2}, {num3} y {num4} es {resultado}")
