import math

def coordenadas(r, theta):
    theta_radianes = math.radians(theta)
    
    x = r * math.cos(theta_radianes)
    y = r * math.sin(theta_radianes)
    
    return x, y

r = float(input("Ingrese la magnitud (r): "))
theta = float(input("Ingrese el ángulo en grados (θ): "))

x, y = coordenadas(r, theta)

print(f"Las coordenadas cartesianas correspondientes son: x = {x}, y = {y}")
