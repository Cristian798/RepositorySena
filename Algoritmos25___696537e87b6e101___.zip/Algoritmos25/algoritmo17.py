def calcularCalificacion(estudiantes, calificaciones):
    calificacionMedia = sum(calificaciones) / len(calificaciones)
    return calificacionMedia

def imprimirCalificaciones(estudiantes, calificaciones):
    calificacionMedia = calcularCalificacion(estudiantes, calificaciones)

    print("La Calificación media es: ", calificacionMedia)

    for i in range(len(estudiantes)):
        diferencia = calificaciones[i] - calificacionMedia
        print(estudiantes[i] + ": " + str(calificaciones[i]) + " (Diferencia con la media: " + str(diferencia) + ")")

estudiantes = str(input("Ingrese el nombre del estudiante: "))
calificaciones = int(input("Ingrese La calificación del estudiante: "))

imprimirCalificaciones(estudiantes, calificaciones)
