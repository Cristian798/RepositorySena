def calcularSalario(horasTrabajadas, salarioHora):
    if horasTrabajadas <= 40:
        salarioTotal = horasTrabajadas * salarioHora
    else:
        horasNormales = 40
        horasExtra = horasTrabajadas - 40
        salarioTotal = (horasNormales * salarioHora) + (horasExtra * 1.5 * salarioHora)
    
    return salarioTotal

# Ejemplo de uso
horasTrabajadas = float(input("Ingrese las horas trabajadas: "))
salarioHora = float(input("Ingrese el salario por hora: "))
salario = calcularSalario(horasTrabajadas, salarioHora)
print(f"El salario total es: ${salario:.2f}")
