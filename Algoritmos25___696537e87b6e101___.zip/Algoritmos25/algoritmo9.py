def digito(caracter):
    if len(caracter) == 1 and caracter.isdigit():
        return True
    else:
        return False

caracter = str(input("Ingrese un numero"))
if digito(caracter):
    print(f"'{caracter}' es un dígito.")
else:
    print(f"'{caracter}' no es un dígito.")
