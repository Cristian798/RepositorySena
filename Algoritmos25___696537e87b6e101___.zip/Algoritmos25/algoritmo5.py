def calcularPotencia(x, n):
    resultado = x ** n
    return resultado

x = float(input("Ingrese el valor de X (real): "))
n = int(input("Ingrese el valor de n (entero): "))

resultado = calcularPotencia(x, n)

print(f"{x} elevado a la potencia {n} es igual a {resultado}")
