def numeroMayor(num1, num2):
    if num1 > num2:
        return num1
    else:
        return num2

num1 = int(input("Ingrese el primer número entero: "))
num2 = int(input("Ingrese el segundo número entero: "))

mayor = numeroMayor(num1, num2)

print(f"El número mayor entre {num1} y {num2} es {mayor}")
