from datetime import datetime

def fechaValida(fecha):
    try:
        fecha = datetime.strptime(fecha, '%d/%m/%Y')
        return True
    except ValueError:
        return False

fecha = input("Ingresa una fecha en el formato dd/mm/yyyy: ")
if fechaValida(fecha):
    print("La fecha es válida.")
else:
    print("La fecha no es válida.")
