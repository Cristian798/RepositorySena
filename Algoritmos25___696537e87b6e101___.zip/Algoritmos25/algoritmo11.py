def divisionEntera(dividendo, divisor):
    if dividendo < divisor:
        return 0, dividendo
    else:
        cociente, resto = divisionEntera(dividendo - divisor, divisor)
        return cociente + 1, resto

dividendo = int(input("Ingrese el numero dividendo"))
divisor = int(input("Ingrese el numero divisor"))
cociente, resto = divisionEntera(dividendo, divisor)
print(f"División entera: {cociente}")
print(f"Resto: {resto}")
