def formatearFecha(dia, mes, anio):
    anio_str = str(anio)[-2:]
    
    dia_str = str(dia).lstrip('0')
    mes_str = str(mes).lstrip('0')

    fecha_nueva = f"{dia_str}/{mes_str}/{anio_str}"
    
    print(fecha_nueva)
    
dia = int(input("Ingrese el día: "))
mes = int(input("Ingrese el mes: "))
anio = int(input("Ingrese el año: "))

formatearFecha(dia, mes, anio)

