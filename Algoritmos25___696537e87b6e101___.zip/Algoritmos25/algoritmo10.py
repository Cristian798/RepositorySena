def valorAbsoluto(numero):
    return abs(numero)

num1 = int(input("Ingrese un numero"))
resultado = valorAbsoluto(num1)
print(f"El valor absoluto de {num1} es {resultado}")
