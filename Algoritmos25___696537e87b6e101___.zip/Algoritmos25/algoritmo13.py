def contarPositivos(lista):
    contador = 0
    for elemento in lista:
        if elemento > 0:
            contador += 1
    return contador

milista = [1, -2, 3, -4, 5, 0, 6]
numerosPositivos = contarPositivos(milista)
print(f"El número de elementos positivos en la lista es: {numerosPositivos}")
