import math

def factorial(n):
    if n < 0:
        return "No se puede calcular el factorial de un numero negativo"
    elif n == 0:
        return 1
    else:
        return math.factorial(n)

num = int(input("Ingrese un numero entre 0 y 1000000 para calcular su factorial: "))

if 0 <= num <= 1000000:
    resultado = factorial(num)
    print(f"El factorial de {num} es {resultado}")
else:
    print("El numero debe estar en el rango de 0 a 1,000,000")

    
