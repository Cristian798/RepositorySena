def ConvertirMayus(palabra):
    palabra = palabra.upper()
    print(palabra)

def ConvertirMinus(palabra):
    palabra = palabra.lower()
    print(palabra)
    
palabra = input("Ingrese una palabra: ")
ConvertirMayus(palabra)
ConvertirMinus(palabra)
