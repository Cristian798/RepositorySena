#Ejercicio 7 
class Persona:
    def __init__(self, nombre, apellido, edad):
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad
    def obtener_nombre_completo(self):
        print(self.nombre + " " + self.apellido)
        print("Su edad es: ", self.edad)

Persona1 = Persona("Cristian", "Cardona", 18)
Persona1.obtener_nombre_completo()        

print("------------------") #Para que no quede pegada la informacion que se muestra en la consola

#Ejercicio 8
class Estudiante(Persona):
    def __init__(self, nombre, apellido, edad, carrera):
        super().__init__(nombre, apellido, edad)
        self.carrera = carrera
    def obtener_nombre_completo(self):
         print(self.nombre + " " + self.apellido)
         print("Su Carrera es: ", self.carrera)

Persona2 = Estudiante("Cristian", "Correa", 18, "Programación de Software")
Persona2.obtener_nombre_completo()

print("------------------") #Para que no quede pegada la informacion que se muestra en la consola

#Ejercicio 9
class Profesor(Persona):
    def __init__(self, nombre, apellido, edad, materia):
        super().__init__(nombre, apellido, edad)
        self.materia = materia
    def obtener_nombre_completo(self):
        print("Profesor: ", self.nombre + " " + self.apellido)
        print("Su Materia es: ", self.materia)

Profesor1 = Profesor("Edwin", "Figueroa", 35, "Tecnologia e Informatica")
Profesor1.obtener_nombre_completo()
  