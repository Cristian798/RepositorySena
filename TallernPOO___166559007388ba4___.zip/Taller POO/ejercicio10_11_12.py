#Ejercicio 10
class Forma:
    def __init__(self, ancho, alto):
        self.ancho = ancho
        self.alto = alto
    def calcular_area(self):
        print("El Area es: ", self.ancho * self.alto)

Forma1 = Forma(66,7)
Forma1.calcular_area()

print("------------------") #Para que no quede pegada la informacion que se muestra en la consola

#Ejercicio 11
class Rectangulo(Forma):
    def calcular_perimetro(self):
        print("El Perimetro es: ", self.ancho * 2 + self.alto * 2)

MiRectangulo = Rectangulo(16,77)
MiRectangulo.calcular_perimetro()

print("------------------") #Para que no quede pegada la informacion que se muestra en la consola

#Ejercicio 12
class Circulo(Forma):
    def calcular_circunferencia(self):
        print("El Circunferencia es: ", self.ancho * 2)

MiCirculo = Circulo(24,0)
MiCirculo.calcular_circunferencia()