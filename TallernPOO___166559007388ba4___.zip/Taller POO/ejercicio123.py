#Ejercicio 1 
class Vehiculo:
    def __init__(self, marca, modelo, anio):
        self.marca = marca
        self.modelo = modelo
        self.anio = anio
    def obtener_info(self):
        print("La Marca es: ", self.marca)
        print("El Modelo es: ", self.modelo)
        print("Año: ", self.anio)

MiCarro = Vehiculo("Toyota", "4Runner", 2023)
MiCarro.obtener_info()

print("------------------") #Para que no quede pegada la informacion que se muestra en la consola 

#Ejercicio 2
class Automovil(Vehiculo):
    def __init__(self, marca, modelo, anio, numero_puertas):
        super().__init__(marca, modelo, anio)
        self.numero_puertas = numero_puertas
    def obtener_info(self):
        super().obtener_info()
        print("Numero de Puertas: ", self.numero_puertas)
        
MiAutomovil = Automovil("Renault", "Sandero", 2023, 5)
MiAutomovil.obtener_info()

print("------------------") #Para que no quede pegada la informacion que se muestra en la consola 

#Ejercicio 3
class Camioneta(Vehiculo):
    def __init__(self, marca, modelo, anio, capacidad_carga):
        super().__init__(marca, modelo, anio)
        self.capacidad_carga = capacidad_carga
    def obtener_info(self):
        super().obtener_info()
        print("Capacidad de Carga: ", self.capacidad_carga)

MiCamioneta = Camioneta("Toyota", "Hilux", 2022, "3000 Kg")
MiCamioneta.obtener_info()

        