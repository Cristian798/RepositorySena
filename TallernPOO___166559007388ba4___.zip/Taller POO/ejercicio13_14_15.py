#Ejercicio 13
class Empleado:
    def __init__(self, nombre, apellido, sueldo):
        self.nombre = nombre
        self.apellido = apellido
        self.sueldo = sueldo
    def calcular_salario_neto(self):
        self.salario_neto = self.sueldo - self.sueldo * 0.15
        print("Su Salario Neto es de: ", self.salario_neto)

Empleado1 = Empleado("Alejandro", "Correa", 100000)
Empleado1.calcular_salario_neto()

print("------------------") #Para que no quede pegada la informacion que se muestra en la consola

#Ejercicio 14
class Gerente(Empleado):
    def __init__(self, nombre, apellido, sueldo, departamento):
        super().__init__(nombre, apellido, sueldo)
        self.departamento = departamento
    def calcular_salario_neto(self):
        super().calcular_salario_neto()
        print("Su Salario Neto es de: ", self.salario_neto)
        if self.salario_neto > 100000:
            self.salario_neto = self.salario_neto - self.salario_neto * 0.15
            print("Su Salario Neto es de: ", self.salario_neto)

Gerente1 = Gerente("Cristian", "Correa", 6000000, "Medellin")
Gerente1.calcular_salario_neto()

print("------------------") #Para que no quede pegada la informacion que se muestra en la consola

#Ejercicio 15  # No se por que el error en este ejercicio
class Programador(Empleado):
    def __init__(self, nombre, apellido, sueldo, lenguaje):
        super().__init__(nombre, apellido, sueldo)
        self.lenguaje = lenguaje
    def calcular_salario_neto(self):
        salario_neto_base = super().calcular_salario_neto()
        bono_lenguaje = 0.1
        salario_neto_programador = salario_neto_base * bono_lenguaje
        print("El Salario del Programador es:", salario_neto_programador)

Programador1 = Programador("Cristian A", "Correa C", 5000000, "Python")
Programador1.calcular_salario_neto()







