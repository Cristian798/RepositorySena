#Ejercicio 4 
class Animal:
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad
    def hacer_ruido(self):
        print("Mensaje Generico")


#Ejercicio 5
class Perro(Animal):
    def __init__(self, nombre, edad, raza):
        super().__init__(nombre, edad)
        self.raza = raza
    def hacer_ruido(self):
        print("El Nombre del perr@ es: ", self.nombre)
        print("La Edad es: ", self.edad)
        print("La Raza es: ", self.raza)
        print("GUAU GUAU")

MiPerro = Perro("Luna", 2, "Golden")
MiPerro.hacer_ruido()

print("------------------") #Para que no quede pegada la informacion que se muestra en la consola

#Ejercicio 6
class Gato(Animal):
    def __init__(self, nombre, edad, raza):
        super().__init__(nombre, edad)
        self.raza = raza
    def hacer_ruido(self):
        print("El Nombre del gat@ es: ", self.nombre)
        print("La Edad es: ", self.edad)
        print("La Raza es: ", self.raza)
        print("MIAU MIAU")

MiGato = Gato("Pardo", 99, "No definida")
MiGato.hacer_ruido()